import os


#c'est très nul
#c'est très bien
print("*")
print("**")
print("***")
print("****")
print("*****")
print("******")
print("*******")
print("********")
print("*********")
print("**********")

i = 0
while i < 500 :
    reponse = input("> $_  ")
    if reponse == "import date.asp":
        print("The file has succeful imported")
    if reponse == "# <iostream.h>":
        iostream = "iostream.display"
    if reponse == "install TeapodShell":
        file = open("teapodshell.jug","w+")
        file.write("[registry]name= terminal AppXRun= Run.exe @terminal")
        file.close()
    if reponse == "print.sel":
        printer = input("|>>>('")
        print("|>>')")
        print(printer)
    i = i +1
    if reponse == "e.virus('calc.jug')":
        os.system("calc.vbs")
        print("certaines parties de virus était supprimés")
    if reponse == "clean()":
        os.system("teapod_cleaner_pro.bat")
if i == 500 :
    print